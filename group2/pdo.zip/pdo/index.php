<?php

use Academy\Database;

require_once __DIR__ . '/vendor/autoload.php';

$db = new Database();

var_dump($db);


