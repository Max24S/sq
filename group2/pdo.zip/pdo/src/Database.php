<?php

namespace Academy;

class Database extends Connect
{

}