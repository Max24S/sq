<?php

namespace Academy;


class Db extends Connect {
    

}
