<?php
use Academy\Db;
require_once __DIR__ . '/vendor/autoload.php';
$db=new Db();

var_dump($db);
?>